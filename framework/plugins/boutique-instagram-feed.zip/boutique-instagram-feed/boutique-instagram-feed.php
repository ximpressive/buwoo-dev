<?php
/*
Plugin Name: Boutique Instagram Feed
Plugin URI: http://krocant.com/
Description: A WordPress widget for showing your latest Instagram photos.
Version: 1.0.0
Author: Krocant
Author URI: http://krocant.com/
Text Domain: boutique-instagram-feed
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

*/

function bif_init() {

	define( 'BOUTIQUE_INSTAGRAM_WIDGET_PATH', dirname( __FILE__ ) );
	define( 'BOUTIQUE_INSTAGRAM_WIDGET_BASE', plugin_basename( __FILE__ ) );
	define( 'BOUTIQUE_INSTAGRAM_WIDGET_FILE', __FILE__ );
}
add_action( 'init', 'bif_init' );

function wpiw_widget() {
	register_widget( 'boutique_instagram_widget' );
}
add_action( 'widgets_init', 'wpiw_widget' );

Class boutique_instagram_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'boutique-instagram-feed',
			__( 'Instagram', 'boutique-instagram-feed' ),
			array(
				'classname' => 'boutique-instagram-feed',
				'description' => esc_html__( 'Displays your latest Instagram photos', 'boutique-instagram-feed' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	function widget( $args, $instance ) {

		$title 		=	empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$username 	=	empty( $instance['username'] ) ? '' : $instance['username'];
		$limit 		=	empty( $instance['number'] ) ? 6 : $instance['number'];
		$size 		=	empty( $instance['size'] ) ? 'small' : $instance['size'];
		$target 	=	empty( $instance['target'] ) ? '_blank' : $instance['target'];
		$link 		=	empty( $instance['link'] ) ? '' : $instance['link'];
		$style 		=	empty( $instance['style'] ) ? '' : $instance['style'];

		echo $args['before_widget'];

		if ( ! empty( $title ) ) { echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; };

		do_action( 'bif_before_widget', $instance );

		if ( '' !== $username ) {

			$media_array = $this->scrape_instagram( $username );

			if ( is_wp_error( $media_array ) ) {

				echo wp_kses_post( $media_array->get_error_message() );

			} else {

				// filter for images only?
				if ( $images_only = apply_filters( 'bif_images_only', false ) ) {
					$media_array 	=	array_filter( $media_array, array( $this, 'images_only' ) );
				}

				// slice list down to required limit.
				$media_array	=	array_slice( $media_array, 0, $limit );

				// filters for custom classes.
				$aclass 		=	apply_filters( 'bif_a_class', '' );
				$imgclass 		=	apply_filters( 'bif_img_class', '' );
				$template_part 	=	apply_filters( 'bif_template_part', 'template_part/boutique-instagram-feed.php' );

				if( $style == 'masonry' ){
					$wrapclass	=	apply_filters( 'bif_list_class', 'gridmasonry instagram-size-' . $size );
					$itemclass 	=	apply_filters( 'bif_item_class', 'itemmasonry col-md-4' );
				}elseif( $style == 'block' ){
					$wrapclass	=	apply_filters( 'bif_list_class', 'insta-images instagram-size-' . $size );
					$itemclass 	=	apply_filters( 'bif_item_class', 'blockimages col-md-3 p-0' );
					$aclass 	=	apply_filters( 'bif_a_class', 'button' );
				}else{
					$wrapclass	=	apply_filters( 'bif_list_class', 'insta-images instagram-size-' . $size );
					$itemclass 	=	apply_filters( 'bif_item_class', 'itemimages col-md-4' );
				}

				?>
				<div class="row">
					<div class="<?php echo esc_attr( $wrapclass ); ?>">
					<?php
						foreach( $media_array as $item ) {
							// copy the else line into a new file (parts/boutique-instagram-feed.php) within your theme and customise accordingly.
							if ( locate_template( $template_part ) !== '' ) {
								include locate_template( $template_part );
							} else {
								echo '<div class="' . esc_attr( $itemclass ) . '">';
								if( $style == 'block' ){	
									
										echo '<div class="imagein">
												<img src="' . esc_url( $item[$size] ) . '"  alt="' . esc_attr( $item['description'] ) . '" title="' . esc_attr( $item['description'] ) . '"  class="' . esc_attr( $imgclass ) . '"/>
											</div>
											<div class="captionin">
												<p>Posted By</p>
												<h4>@'. $username .'</h4>
												<a href="' . esc_url( $item['link'] ) . '" target="' . esc_attr( $target ) . '" class="' . esc_attr( $aclass ) . '">Shop Today <i class="fa fa-caret-right" aria-hidden="true"></i></a>
											</div>';
									}else{
										
										echo '<a href="' . esc_url( $item['link'] ) . '" target="' . esc_attr( $target ) . '"  class="' . esc_attr( $aclass ) . '">

												<img src="' . esc_url( $item[$size] ) . '"  alt="' . esc_attr( $item['description'] ) . '" title="' . esc_attr( $item['description'] ) . '"  class="' . esc_attr( $imgclass ) . '"/>
											</a>';
										
									}	
									echo '</div>';
							}
						}
					?>
					<br clear="all">
					</div>
				</div>	
				<?php
			}
		}

		$linkclass 	=	apply_filters( 'bif_link_class', 'clear' );
		$linkaclass =	apply_filters( 'bif_linka_class', '' );

		switch ( substr( $username, 0, 1 ) ) {
			case '#':
				$url = '//instagram.com/explore/tags/' . str_replace( '#', '', $username );
				break;

			default:
				$url = '//instagram.com/' . str_replace( '@', '', $username );
				break;
		}

		if ( '' !== $link ) {
			?><p class="<?php echo esc_attr( $linkclass ); ?>"><a href="<?php echo trailingslashit( esc_url( $url ) ); ?>" rel="me" target="<?php echo esc_attr( $target ); ?>" class="<?php echo esc_attr( $linkaclass ); ?>"><?php echo wp_kses_post( $link ); ?></a></p><?php
		}

		do_action( 'bif_after_widget', $instance );

		echo $args['after_widget'];
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' 	=>	__( 'Instagram', 'boutique-instagram-feed' ),
			'username' 	=>	'',
			'size' 		=>	'small',
			'link' 		=>	__( 'Follow Me!', 'boutique-instagram-feed' ),
			'number' 	=>	6,
			'target' 	=>	'_blank',
			'style' 	=>	'grid',
		) );
		$title 		=	$instance['title'];
		$username 	=	$instance['username'];
		$number 	=	absint( $instance['number'] );
		$size 		=	$instance['size'];
		$target 	=	$instance['target'];
		$link 		=	$instance['link'];
		$style 		=	$instance['style'];
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'boutique-instagram-feed' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>"><?php esc_html_e( '@username or #tag', 'boutique-instagram-feed' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'username' ) ); ?>" type="text" value="<?php echo esc_attr( $username ); ?>" /></label></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of photos', 'boutique-instagram-feed' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" /></label></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>"><?php esc_html_e( 'Photo size', 'boutique-instagram-feed' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'size' ) ); ?>" class="widefat">
				<option value="thumbnail" <?php selected( 'thumbnail', $size ); ?>><?php esc_html_e( 'Thumbnail', 'boutique-instagram-feed' ); ?></option>
				<option value="small" <?php selected( 'small', $size ); ?>><?php esc_html_e( 'Small', 'boutique-instagram-feed' ); ?></option>
				<option value="large" <?php selected( 'large', $size ); ?>><?php esc_html_e( 'Large', 'boutique-instagram-feed' ); ?></option>
				<option value="original" <?php selected( 'original', $size ); ?>><?php esc_html_e( 'Original', 'boutique-instagram-feed' ); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"><?php esc_html_e( 'Open links in', 'boutique-instagram-feed' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'target' ) ); ?>" class="widefat">
				<option value="_self" <?php selected( '_self', $target ); ?>><?php esc_html_e( 'Current window (_self)', 'boutique-instagram-feed' ); ?></option>
				<option value="_blank" <?php selected( '_blank', $target ); ?>><?php esc_html_e( 'New window (_blank)', 'boutique-instagram-feed' ); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link text', 'boutique-instagram-feed' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_attr( $link ); ?>" /></label></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Styles', 'boutique-instagram-feed' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>" class="widefat">
				<option value="grid" <?php selected( 'grid', $style ); ?>><?php esc_html_e( 'Grid', 'boutique-instagram-feed' ); ?></option>
				<option value="masonry" <?php selected( 'masonry', $style ); ?>><?php esc_html_e( 'Masonry', 'boutique-instagram-feed' ); ?></option>
				<option value="block" <?php selected( 'block', $style ); ?>><?php esc_html_e( 'Blocks', 'boutique-instagram-feed' ); ?></option>
			</select>
		</p>
		<?php

	}

	function update( $new_instance, $old_instance ) {
		$instance 				=	$old_instance;
		$instance['title'] 		=	strip_tags( $new_instance['title'] );
		$instance['username'] 	=	trim( strip_tags( $new_instance['username'] ) );
		$instance['number'] 	=	! absint( $new_instance['number'] ) ? 9 : $new_instance['number'];
		$instance['size'] 		=	( ( 'thumbnail' === $new_instance['size'] || 'large' === $new_instance['size'] || 'small' === $new_instance['size'] || 'original' === $new_instance['size'] ) ? $new_instance['size'] : 'large' );
		$instance['target'] 	=	( ( '_self' === $new_instance['target'] || '_blank' === $new_instance['target'] ) ? $new_instance['target'] : '_self' );
		$instance['link'] 		=	strip_tags( $new_instance['link'] );
		$instance['style'] 		=	strip_tags( $new_instance['style'] );
		return $instance;
	}

	// based on https://gist.github.com/cosmocatalano/4544576.
	function scrape_instagram( $username ) {

		$username = trim( strtolower( $username ) );

		switch ( substr( $username, 0, 1 ) ) {
			case '#':
				$url              = 'https://instagram.com/explore/tags/' . str_replace( '#', '', $username );
				$transient_prefix = 'h';
				break;

			default:
				$url              = 'https://instagram.com/' . str_replace( '@', '', $username );
				$transient_prefix = 'u';
				break;
		}

		if ( false === ( $instagram = get_transient( 'insta-a10-' . $transient_prefix . '-' . sanitize_title_with_dashes( $username ) ) ) ) {

			$remote = wp_remote_get( $url );

			if ( is_wp_error( $remote ) ) {
				return new WP_Error( 'site_down', esc_html__( 'Unable to communicate with Instagram.', 'boutique-instagram-feed' ) );
			}

			if ( 200 !== wp_remote_retrieve_response_code( $remote ) ) {
				return new WP_Error( 'invalid_response', esc_html__( 'Instagram did not return a 200.', 'boutique-instagram-feed' ) );
			}

			$shards      = explode( 'window._sharedData = ', $remote['body'] );
			$insta_json  = explode( ';</script>', $shards[1] );
			$insta_array = json_decode( $insta_json[0], true );

			if ( ! $insta_array ) {
				return new WP_Error( 'bad_json', esc_html__( 'Instagram has returned invalid data.', 'boutique-instagram-feed' ) );
			}

			if ( isset( $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] ) ) {
				$images = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'];
			} elseif ( isset( $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'] ) ) {
				$images = $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'];
			} else {
				return new WP_Error( 'bad_json_2', esc_html__( 'Instagram has returned invalid data.', 'boutique-instagram-feed' ) );
			}

			if ( ! is_array( $images ) ) {
				return new WP_Error( 'bad_array', esc_html__( 'Instagram has returned invalid data.', 'boutique-instagram-feed' ) );
			}

			$instagram = array();

			foreach ( $images as $image ) {
				if ( true === $image['node']['is_video'] ) {
					$type = 'video';
				} else {
					$type = 'image';
				}

				$caption 	=	__( 'Instagram Image', 'boutique-instagram-feed' );
				if ( ! empty( $image['node']['edge_media_to_caption']['edges'][0]['node']['text'] ) ) {
					$caption = wp_kses( $image['node']['edge_media_to_caption']['edges'][0]['node']['text'], array() );
				}

				$instagram[] = array(
					'description' => $caption,
					'link'        => trailingslashit( '//instagram.com/p/' . $image['node']['shortcode'] ),
					'time'        => $image['node']['taken_at_timestamp'],
					'comments'    => $image['node']['edge_media_to_comment']['count'],
					'likes'       => $image['node']['edge_liked_by']['count'],
					'thumbnail'   => preg_replace( '/^https?\:/i', '', $image['node']['thumbnail_resources'][0]['src'] ),
					'small'       => preg_replace( '/^https?\:/i', '', $image['node']['thumbnail_resources'][2]['src'] ),
					'large'       => preg_replace( '/^https?\:/i', '', $image['node']['thumbnail_resources'][4]['src'] ),
					'original'    => preg_replace( '/^https?\:/i', '', $image['node']['display_url'] ),
					'type'        => $type,
				);
			} // End foreach().

			// do not set an empty transient - should help catch private or empty accounts.
			if ( ! empty( $instagram ) ) {
				$instagram = base64_encode( serialize( $instagram ) );
				set_transient( 'insta-a10-' . $transient_prefix . '-' . sanitize_title_with_dashes( $username ), $instagram, apply_filters( 'null_instagram_cache_time', HOUR_IN_SECONDS * 2 ) );
			}
		}

		if ( ! empty( $instagram ) ) {

			return unserialize( base64_decode( $instagram ) );

		} else {

			return new WP_Error( 'no_images', esc_html__( 'Instagram did not return any images.', 'boutique-instagram-feed' ) );

		}
	}

	function images_only( $media_item ) {

		if ( 'image' === $media_item['type'] ) {
			return true;
		}

		return false;
	}
}
